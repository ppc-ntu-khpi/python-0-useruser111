# a = 406 * 1.60934
# print (a)

# x = 10
# y = "20"
# a=x*y
# print (a)